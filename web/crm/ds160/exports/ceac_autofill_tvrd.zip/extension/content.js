(function(){
  if(document.getElementById('tvrd-panel'))return;

  const panel=document.createElement('div');
  panel.id='tvrd-panel';
  panel.style.cssText='position:fixed;bottom:0;right:0;width:290px;background:#001F73;color:#fff;font-family:Arial,sans-serif;font-size:12px;z-index:99999;border-radius:12px 0 0 0;box-shadow:-2px -2px 12px rgba(0,0,0,.3)';
  panel.innerHTML=`
    <div id="tvrd-hdr" style="padding:8px 12px;display:flex;align-items:center;justify-content:space-between;cursor:pointer">
      <span style="font-weight:700">🛂 TengoVisaRD DS-160</span>
      <span id="tvrd-pg" style="font-size:10px;opacity:.7"></span>
      <span id="tvrd-tog" style="font-size:14px">▲</span>
    </div>
    <div id="tvrd-body" style="background:#fff;color:#0F172A;padding:10px">
      <div id="tvrd-cli" style="font-size:11px;color:#475569;margin-bottom:7px;font-weight:600">Sin datos — carga el JSON</div>
      <div id="tvrd-sta" style="font-size:11px;background:#EAF0FF;color:#001F73;padding:5px 8px;border-radius:6px;margin-bottom:7px">Abre la extensión y carga el JSON</div>
      <div id="tvrd-pw" style="background:#E2E8F0;border-radius:10px;height:4px;margin-bottom:7px;display:none">
        <div id="tvrd-pr" style="height:100%;background:#001F73;width:0%;transition:width .3s;border-radius:10px"></div>
      </div>
      <div style="display:flex;gap:6px">
        <button id="tvrd-btn" style="flex:1;padding:8px;background:#001F73;color:#fff;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;font-family:Arial" disabled>▶ Llenar página</button>
        <button id="tvrd-next" style="padding:8px 10px;background:#16A34A;color:#fff;border:none;border-radius:7px;font-size:12px;font-weight:700;cursor:pointer;font-family:Arial" title="Siguiente página">Next ›</button>
      </div>
    </div>
  `;
  document.body.appendChild(panel);

  // Detectar página por URL — más confiable
  function detectPage(){
    const url=window.location.href.toLowerCase();
    const node=(url.match(/[?&]node=([^&]+)/)||[])[1]||'';
    const map={
      'personal1':'P1','personal2':'P2','address':'P3','passport':'P4',
      'travel':'P5','travelcompanions':'P6','previousustravel':'P7','previoustravel':'P7',
      'poc':'P8','uscontact':'P8','family1':'P9A','family2':'P9B',
      'workeducation1':'P10','workeducation2':'P11','workeducation3':'P12',
      'securityandbackground1':'P13','securityandbackground2':'P14',
      'securityandbackground3':'P15','securityandbackground4':'P16',
      'securitybackground1':'P13','securitybackground2':'P14',
      'securitybackground3':'P15','securitybackground4':'P16',
      'preparedby':'PFINAL','preparer':'PFINAL'
    };
    if(map[node])return{page:map[node],node};
    // Fallback por título
    const t=document.title.toLowerCase();
    if(t.includes('personal 1')||t.includes('personal information 1'))return{page:'P1',node};
    if(t.includes('personal 2')||t.includes('personal information 2'))return{page:'P2',node};
    if(t.includes('address'))return{page:'P3',node};
    if(t.includes('passport'))return{page:'P4',node};
    if(t.includes('travel information'))return{page:'P5',node};
    if(t.includes('companion'))return{page:'P6',node};
    if(t.includes('previous'))return{page:'P7',node};
    if(t.includes('point of contact')||t.includes('poc'))return{page:'P8',node};
    if(t.includes('family')&&!t.includes('spouse'))return{page:'P9A',node};
    if(t.includes('spouse')||t.includes('marital'))return{page:'P9B',node};
    if(t.includes('work')||t.includes('occupation'))return{page:'P10',node};
    if(t.includes('previous employ'))return{page:'P11',node};
    if(t.includes('additional')||t.includes('background information 1'))return{page:'P12',node};
    if(t.includes('security')&&t.includes('1'))return{page:'P13',node};
    if(t.includes('security')&&t.includes('2'))return{page:'P14',node};
    if(t.includes('security')&&t.includes('3'))return{page:'P15',node};
    if(t.includes('security')&&t.includes('4'))return{page:'P16',node};
    if(t.includes('prepared'))return{page:'PFINAL',node};
    return{page:'UNKNOWN',node};
  }

  const PAGES={'P1':'Personal 1','P2':'Personal 2','P3':'Dirección','P4':'Pasaporte',
    'P5':'Viaje','P6':'Compañeros','P7':'Viajes Previos','P8':'Contacto EE.UU.',
    'P9A':'Familia','P9B':'Cónyuge','P10':'Trabajo','P11':'Edu/Emp Ant.',
    'P12':'Info Adicional','P13':'Seguridad 1','P14':'Seguridad 2',
    'P15':'Seguridad 3','P16':'Seguridad 4','PFINAL':'Preparador'};

  let collapsed=false;
  document.getElementById('tvrd-hdr').addEventListener('click',function(){
    const b=document.getElementById('tvrd-body');
    const t=document.getElementById('tvrd-tog');
    collapsed=!collapsed;b.style.display=collapsed?'none':'block';t.textContent=collapsed?'▼':'▲';
  });

  // Botón Next — hace click en el botón Next del CEAC
  document.getElementById('tvrd-next').addEventListener('click',function(){
    const ids=['ctl00_ucNavigateOption_ucNavPanel_ctl01_btnNextPageComplete',
               'ctl00_SiteContentPlaceHolder_UpdateButton2','ctl00_SiteContentPlaceHolder_UpdateButton1'];
    for(const id of ids){const e=document.getElementById(id);if(e){e.click();return;}}
    const e=document.querySelector('input[value*="Next"],a[id*="Next"]');if(e)e.click();
  });

  function setStatus(msg,bg,color){
    const s=document.getElementById('tvrd-sta');
    s.textContent=msg;s.style.background=bg||'#EAF0FF';s.style.color=color||'#001F73';
  }
  function setProgress(pct,step){
    const pw=document.getElementById('tvrd-pw');pw.style.display='block';
    document.getElementById('tvrd-pr').style.width=pct+'%';
    setStatus(step);
  }

  function loadData(){
    const{page,node}=detectPage();
    const lbl=PAGES[page]||('?'+node);
    document.getElementById('tvrd-pg').textContent=lbl;
    chrome.storage.local.get('ds160',function(r){
      if(r.ds160&&r.ds160.meta){
        const m=r.ds160.meta;
        document.getElementById('tvrd-cli').textContent=((m.nombre||'')+' '+(m.apellido||'')).trim()+' · '+m.completeness_pct+'%';
        document.getElementById('tvrd-btn').disabled=false;
        if(page==='UNKNOWN'){
          setStatus('⚠️ Página no mapeada: '+node+'\nURL: '+window.location.href.split('?')[1],'#FFF4DE','#92400e');
          document.getElementById('tvrd-btn').disabled=true;
        } else {
          setStatus('✅ Listo — '+lbl,'#EAF8EE','#15803d');
        }
      } else {
        document.getElementById('tvrd-cli').textContent='Sin datos — abre extensión';
        setStatus('Carga el JSON primero','#FEF9EE','#92400e');
        document.getElementById('tvrd-btn').disabled=true;
      }
    });
  }
  loadData();

  document.getElementById('tvrd-btn').addEventListener('click',function(){
    chrome.storage.local.get('ds160',async function(r){
      if(!r.ds160)return;
      document.getElementById('tvrd-btn').disabled=true;
      document.getElementById('tvrd-btn').textContent='⏳ Llenando...';
      try{await fillPage(r.ds160,detectPage().page);}
      catch(e){setStatus('❌ '+e.message,'#FFF5F5','#DC2626');document.getElementById('tvrd-btn').disabled=false;document.getElementById('tvrd-btn').textContent='▶ Llenar página';}
    });
  });

  async function fillPage(data,page){
    const F=data.fields||{};
    const P='ctl00_SiteContentPlaceHolder_FormView1_';
    function g(k,d=''){const v=F[k];return(v&&String(v).trim()&&v!=='null'&&v!=='None')?String(v).trim():d;}
    function gd(k){const v=g(k);if(!v)return{day:'',month:'',year:''};try{const d=new Date(v+'T12:00:00');const M=['JAN','FEB','MAR','APR','MAY','JUN','JUL','AUG','SEP','OCT','NOV','DEC'];return{day:String(d.getDate()),month:M[d.getMonth()],year:String(d.getFullYear())};}catch{return{day:'',month:'',year:''};}};
    function yn(k){return['YES','SI','SÍ','TRUE'].includes(g(k,'NO').toUpperCase());}
    function fi(id,v){if(!v||v==='null')return false;const e=document.getElementById(id);if(!e)return false;e.value=v;['change','input','blur'].forEach(ev=>e.dispatchEvent(new Event(ev,{bubbles:true})));return true;}
    function se(id,v,byText=false){if(!v)return false;const e=document.getElementById(id);if(!e||e.tagName!=='SELECT')return false;const opts=Array.from(e.options);const m=byText?opts.find(o=>o.text.toUpperCase().includes(v.toUpperCase())):opts.find(o=>o.value.toUpperCase()===v.toUpperCase()||o.value.toUpperCase().includes(v.toUpperCase()));if(m){e.value=m.value;e.dispatchEvent(new Event('change',{bubbles:true}));return true;}return false;}
    function cb(id,chk){const e=document.getElementById(id);if(!e)return false;if(chk&&!e.checked)e.click();else if(!chk&&e.checked)e.click();return true;}
    function cl(id){const e=document.getElementById(id);if(e){e.click();return true;}return false;}
    function ta(id,v){if(!v)return;const e=document.getElementById(id);if(e){e.value=v;e.dispatchEvent(new Event('input',{bubbles:true}));}}
    function delay(ms){return new Promise(r=>setTimeout(r,ms));}

    if(page==='P1'){
      setProgress(15,'Nombre...');
      fi(P+'tbxAPP_SURNAME',g('q1_apellido'));fi(P+'tbxAPP_GIVEN_NAME',g('q2_nombre'));
      cb(P+'cbexAPP_FULL_NAME_NATIVE_NA',true);
      cl(P+'rblOtherNames_1');cl(P+'rblTelecodeQuestion_1');
      setProgress(55,'Sexo, civil, nacimiento...');
      se(P+'ddlAPP_GENDER',g('q7_sexo','M').toUpperCase()==='M'?'M':'F');
      const cm={soltero:'S',single:'S',casado:'M',married:'M',viudo:'W',divorciado:'D',separado:'SP'};
      se(P+'ddlAPP_MARITAL_STATUS',cm[g('q8_civil','').toLowerCase()]||'S');
      const db=gd('q9_dob');se(P+'ddlDOBDay',db.day);se(P+'ddlDOBMonth',db.month,true);fi(P+'tbxDOBYear',db.year);
      fi(P+'tbxAPP_POB_CITY',g('q10_ciudad_nac'));
      const prov=g('q11_prov_nac');cb(P+'cbexAPP_POB_ST_PROVINCE_NA',!prov);if(prov)fi(P+'tbxAPP_POB_ST_PROVINCE',prov);
      se(P+'ddlAPP_POB_CNTRY','DOMR');
    }
    else if(page==='P2'){
      setProgress(25,'Nacionalidad...');se(P+'ddlAPP_NATL','DOMR');
      cl(P+'rblAPP_OTH_NATL_IND_1');cl(P+'rblPermResOtherCntryInd_1');
      const ced=g('q20_cedula');
      cb(P+'cbexAPP_NATIONAL_ID_NA',!ced);if(ced){await delay(150);fi(P+'tbxAPP_NATIONAL_ID',ced);}
      cb(P+'cbexAPP_SSN_NA',true);cb(P+'cbexAPP_TAX_ID_NA',true);
    }
    else if(page==='P3'){
      setProgress(15,'Dirección...');
      fi(P+'tbxAPP_ADDR_LN1',g('q23_dir1'));fi(P+'tbxAPP_ADDR_LN2',g('q24_dir2')||'');fi(P+'tbxAPP_ADDR_CITY',g('q25_ciudad'));
      const st=g('q26_provincia');cb(P+'cbexAPP_ADDR_STATE_NA',!st);if(st)fi(P+'tbxAPP_ADDR_STATE',st);
      const zip=g('q27_postal');cb(P+'cbexAPP_ADDR_POSTAL_CD_NA',!zip);if(zip)fi(P+'tbxAPP_ADDR_POSTAL_CD',zip);
      se(P+'ddlCountry','DOMR');cl(P+'rblMailingAddrSame_0');
      setProgress(55,'Teléfono y email...');
      fi(P+'tbxAPP_HOME_TEL',g('q33_tel'));
      const mob=g('q34_tel2');cb(P+'cbexAPP_MOBILE_TEL_NA',!mob);if(mob)fi(P+'tbxAPP_MOBILE_TEL',mob);
      cb(P+'cbexAPP_BUS_TEL_NA',true);cl(P+'rblAddPhone_1');
      fi(P+'tbxAPP_EMAIL_ADDR',g('q36_email'));cl(P+'rblAddEmail_1');
      if(g('q38_red1')&&g('q39_user1')){se(P+'dtlSocial_ctl00_ddlSocialMedia',g('q38_red1'),true);fi(P+'dtlSocial_ctl00_tbxSocialMediaIdent',g('q39_user1'));}
      cl(P+'rblAddSocial_1');
    }
    else if(page==='P4'){
      setProgress(25,'Número y tipo...');
      // P4 IDs reales verificados
      fi(P+'tbxPPT_NUM',g('q43_numpas'));
      // Libreta DNA
      cb(P+'cbexPPT_BOOK_NUM_NA',true);
      // País emisor
      ['ddlPPT_ISSUED_CNTRY','ddlPPT_ISSUED_IN_CNTRY'].forEach(id=>se(P+id,'DOMR'));
      fi(P+'tbxPPT_ISSUED_IN_CITY',g('q46_ciudad_emision')||g('q25_ciudad'));
      fi(P+'tbxPPT_ISSUED_IN_STATE',g('q47_prov_emision')||'');
      ['ddlAPP_PASSPORT_ISSUED_COUNTRY','ddlPPT_ISSUED_CNTRY'].forEach(id=>se(P+id,'DOMR'));
      ['tbxAPP_PASSPORT_ISSUED_CITY','tbxPPT_ISSUE_CITY'].forEach(id=>fi(P+id,g('q46_ciudad_emision')||g('q25_ciudad')));
      cb(P+'cbexAPP_POB_ST_PROVINCE_NA',true);// provincia emisión DNA
      setProgress(65,'Fechas...');
      const pi=gd('q48_emision'),pe=gd('q49_vence');
      se(P+'ddlPPT_ISSUED_DTEDay',pi.day);
      se(P+'ddlPPT_ISSUED_DTEMonth',pi.month,true);
      fi(P+'tbxPPT_ISSUEDYear',pi.year);
      se(P+'ddlPPT_EXPIRE_DTEDay',pe.day);
      se(P+'ddlPPT_EXPIRE_DTEMonth',pe.month,true);
      fi(P+'tbxPPT_EXPIREYear',pe.year);
      // ¿Perdió pasaporte? — No
      cl(P+'rblLOST_PPT_IND_1');
      ['ddlAPP_PASSPORT_ISSUED_MONTH','ddlPPT_ISSUED_MONTH','dlstPPT_ISSUE_MONTH'].forEach(id=>se(P+id,pi.month,true));
      ['tbxAPP_PASSPORT_ISSUED_YEAR','tbxPPT_ISSUE_YR'].forEach(id=>fi(P+id,pi.year));
      ['ddlAPP_PASSPORT_EXPIRE_DAY','ddlPPT_EXPIRE_DAY'].forEach(id=>se(P+id,pe.day));
      ['ddlAPP_PASSPORT_EXPIRE_MONTH','ddlPPT_EXPIRE_MONTH'].forEach(id=>se(P+id,pe.month,true));
      ['tbxAPP_PASSPORT_EXPIRE_YEAR','tbxPPT_EXPIRE_YR'].forEach(id=>fi(P+id,pe.year));
    }
    else if(page==='P5'){
      // VIAJE — propósito + pago + compañeros (todo en una página)
      setProgress(15,'Propósito del viaje...');
      // Clase de visa — B (Tourist/Business)
      const purp=document.querySelector('select[id*="VISA_CLASS"],select[id*="PURPOSE"],select[id*="PurposeOfTrip"]');
      if(purp){const ob=Array.from(purp.options).find(o=>o.value==='B'||o.text.includes('BUSINESS OR PLEASURE'));if(ob){purp.value=ob.value;purp.dispatchEvent(new Event('change',{bubbles:true}));}}
      await delay(300);
      // ¿Planes específicos? — No
      document.querySelectorAll('input[type="radio"]').forEach(e=>{if(e.id&&e.id.toLowerCase().includes('specificplan')&&e.value==='N')e.click();if(e.id&&e.id.toLowerCase().includes('specifictravel')&&e.value==='N')e.click();});
      setProgress(45,'Quién paga...');
      // Quién paga — Self
      const payerSel=document.querySelector('select[id*="Payer"],select[id*="PAYER"],select[id*="Paying"]');
      if(payerSel){const os=Array.from(payerSel.options).find(o=>o.value==='S'||o.text.toLowerCase().includes('self'));if(os){payerSel.value=os.value;payerSel.dispatchEvent(new Event('change',{bubbles:true}));}}
      await delay(300);
      fi(P+'tbxPayerPhone',g('q33_tel'));
      const pe2=g('q36_email');cb(P+'cbxDNAPAYER_EMAIL_ADDR_NA',!pe2);if(pe2)fi(P+'tbxPAYER_EMAIL_ADDR',pe2);
      // Dirección pagador — misma
      const rSame=document.querySelector('input[id*="PayerAddr"][value="Y"],input[id*="payeraddr"][value="Y"]');if(rSame)rSame.click();
      setProgress(75,'Compañeros — No...');
      // Sin compañeros
      const rNoComp=document.querySelector('input[id*="TravelingWith"][value="N"],input[id*="OtherPersons"][value="N"]');if(rNoComp)rNoComp.click();
    }
    else if(page==='P6'){
      setProgress(50,'Compañeros — No...');
      document.querySelectorAll('input[type="radio"][value="N"]').forEach(e=>{if(!e.checked)e.click();});
    }
    else if(page==='P7'){
      setProgress(20,'Viajes previos...');
      // ¿Estuvo en EE.UU.?
      const wasUS=yn('q82_estuvo');
      document.querySelectorAll('input[type="radio"]').forEach(e=>{
        if(e.id&&(e.id.toLowerCase().includes('prevustravel')||e.id.toLowerCase().includes('previousustravel'))){
          if((wasUS&&e.value==='Y')||(!wasUS&&e.value==='N'))e.click();
        }
      });
      if(wasUS){
        await delay(300);
        const v1=gd('q83_fecha_vis1');
        if(v1.day){
          const d1=document.querySelector('select[id*="ARR_DAY_1"],select[id*="ArrDay_1"]');if(d1)se(d1.id,v1.day);
          const m1=document.querySelector('select[id*="ARR_MONTH_1"],select[id*="ArrMonth_1"]');if(m1)se(m1.id,v1.month,true);
          const y1=document.querySelector('input[id*="ARR_YEAR_1"],input[id*="ArrYear_1"]');if(y1)fi(y1.id,v1.year);
        }
      }
      setProgress(55,'Visa anterior...');
      const hadVisa=yn('q87_visa_prev');
      document.querySelectorAll('input[type="radio"]').forEach(e=>{
        if(e.id&&(e.id.toLowerCase().includes('prevvisa')||e.id.toLowerCase().includes('previousvisa'))){
          if((hadVisa&&e.value==='Y')||(!hadVisa&&e.value==='N'))e.click();
        }
      });
      setProgress(80,'Negación...');
      const denied=yn('q93_negacion');
      document.querySelectorAll('input[type="radio"]').forEach(e=>{
        if(e.id&&(e.id.toLowerCase().includes('denied')||e.id.toLowerCase().includes('visarefusal'))){
          if((denied&&e.value==='Y')||(!denied&&e.value==='N'))e.click();
        }
      });
      if(denied){await delay(200);const ex=document.querySelector('textarea[id*="enied"],textarea[id*="DENIED"]');if(ex)ta(ex.id,g('q95_razon_neg')||'Visa denied previously');}
      // Petición — N
      document.querySelectorAll('input[type="radio"]').forEach(e=>{if(e.id&&e.id.toLowerCase().includes('petition')&&e.value==='N')e.click();});
    }
    else if(page==='P8'){
      setProgress(20,'Contacto EE.UU....');
      fi(P+'tbxUS_POC_SURNAME',g('q98_cont_ap'));fi(P+'tbxUS_POC_GIVEN_NAME',g('q99_cont_nom'));
      cb(P+'cbxUS_POC_NAME_NA',!g('q98_cont_ap'));cb(P+'cbxUS_POC_ORG_NA_IND',true);
      const rm={AMIGO:'F',FRIEND:'F',FAMILIAR:'R',RELATIVE:'R',EMPLEADOR:'E',OTHER:'O',OTRO:'O'};
      se(P+'ddlUS_POC_REL_TO_APP',rm[g('q101_cont_rel','OTHER').toUpperCase()]||'O');
      fi(P+'tbxUS_POC_ADDR_LN1',g('q102_cont_dir'));fi(P+'tbxUS_POC_ADDR_CITY',g('q103_cont_ciudad'));
      se(P+'ddlUS_POC_ADDR_STATE',g('q104_cont_estado'),true);
      fi(P+'tbxUS_POC_ADDR_POSTAL_CD',g('q105_cont_zip')||'00000');fi(P+'tbxUS_POC_HOME_TEL',g('q106_cont_tel'));
      const em=g('q107_cont_email');cb(P+'cbexUS_POC_EMAIL_ADDR_NA',!em);if(em)fi(P+'tbxUS_POC_EMAIL_ADDR',em);
    }
    else if(page==='P9A'){
      setProgress(20,'Padre...');
      const pa=g('q108_padre_ap'),pn=g('q109_padre_nom');
      cb(P+'cbxFATHER_SURNAME_UNK_IND',!pa);if(pa)fi(P+'tbxFATHER_SURNAME',pa);
      cb(P+'cbxFATHER_GIVEN_NAME_UNK_IND',!pn);if(pn)fi(P+'tbxFATHER_GIVEN_NAME',pn);
      const pd=gd('q110_padre_dob');
      if(pd.day){se(P+'ddlFathersDOBDay',pd.day);se(P+'ddlFathersDOBMonth',pd.month,true);fi(P+'tbxFathersDOBYear',pd.year);}
      else cb(P+'cbxFATHER_DOB_UNK_IND',true);
      if(yn('q111_padre_eeuu'))cl(P+'rblFATHER_LIVE_IN_US_IND_0');else cl(P+'rblFATHER_LIVE_IN_US_IND_1');
      await delay(200);
      setProgress(55,'Madre...');
      const ma=g('q113_madre_ap'),mn=g('q114_madre_nom');
      cb(P+'cbxMOTHER_SURNAME_UNK_IND',!ma);if(ma)fi(P+'tbxMOTHER_SURNAME',ma);
      cb(P+'cbxMOTHER_GIVEN_NAME_UNK_IND',!mn);if(mn)fi(P+'tbxMOTHER_GIVEN_NAME',mn);
      const md=gd('q115_madre_dob');
      if(md.day){se(P+'ddlMothersDOBDay',md.day);se(P+'ddlMothersDOBMonth',md.month,true);fi(P+'tbxMothersDOBYear',md.year);}
      else cb(P+'cbxMOTHER_DOB_UNK_IND',true);
      if(yn('q116_madre_eeuu'))cl(P+'rblMOTHER_LIVE_IN_US_IND_0');else cl(P+'rblMOTHER_LIVE_IN_US_IND_1');
      await delay(200);
      if(yn('q118_fam_inm'))cl(P+'rblUS_IMMED_RELATIVE_IND_0');else cl(P+'rblUS_IMMED_RELATIVE_IND_1');
      cl(P+'rblUS_OTHER_RELATIVE_IND_1');
    }
    else if(page==='P9B'){
      setProgress(50,'Cónyuge...');
      fi(P+'tbxSpouseSurname',g('q125_con_ap'));fi(P+'tbxSpouseGivenName',g('q126_con_nom'));
      const sd=gd('q127_con_dob');
      if(sd.day){se(P+'ddlDOBDay',sd.day);se(P+'ddlDOBMonth',sd.month,true);fi(P+'tbxDOBYear',sd.year);}
      se(P+'ddlSpouseNatDropDownList','DOMR');
      fi(P+'tbxSpousePOBCity',g('q10_ciudad_nac'));se(P+'ddlSpousePOBCountry','DOMR');se(P+'ddlSpouseAddressType','H');
    }
    else if(page==='P10'){
      setProgress(20,'Ocupación...');
      const om={EMPLOYED:'B',STUDENT:'S','SELF-EMPLOYED':'F',RETIRED:'R',UNEMPLOYED:'U',HOMEMAKER:'H',OTHER:'O'};
      se(P+'ddlPresentOccupation',om[g('q131_ocupacion','EMPLOYED').toUpperCase()]||'B');
      await delay(500);
      fi(P+'tbxEmpSchName',g('q132_empleador')||'N/A');fi(P+'tbxEmpSchAddr1',g('q133_dir_emp1')||'N/A');
      fi(P+'tbxEmpSchCity',g('q134_emp_ciudad')||g('q25_ciudad'));
      cb(P+'cbxWORK_EDUC_ADDR_STATE_NA',true);cb(P+'cbxWORK_EDUC_ADDR_POSTAL_CD_NA',true);
      fi(P+'tbxWORK_EDUC_TEL',g('q138_emp_tel')||g('q33_tel'));se(P+'ddlEmpSchCountry','DOMR');
      const es=gd('q139_emp_inicio');
      if(es.day){se(P+'ddlEmpDateFromDay',es.day);se(P+'ddlEmpDateFromMonth',es.month,true);fi(P+'tbxEmpDateFromYear',es.year);}
      cb(P+'cbxCURR_MONTHLY_SALARY_NA',!g('q140_salario'));if(g('q140_salario'))fi(P+'tbxCURR_MONTHLY_SALARY',g('q140_salario'));
      ta(P+'tbxDescribeDuties',g('q141_funciones')||'Administrative and management duties');
    }
    else if(page==='P11'){
      setProgress(35,'Empleo anterior...');
      if(yn('q142_emp_ant'))cl(P+'rblPreviouslyEmployed_0');else cl(P+'rblPreviouslyEmployed_1');
      setProgress(70,'Educación...');
      if(yn('q151_edu'))cl(P+'rblOtherEduc_0');else cl(P+'rblOtherEduc_1');
      if(yn('q151_edu')){
        await delay(300);
        fi(P+'dtlPrevEduc_ctl00_tbxSchoolName',g('q152_escuela'));
        fi(P+'dtlPrevEduc_ctl00_tbxSchoolCity',g('q25_ciudad'));
        cb(P+'dtlPrevEduc_ctl00_cbxEDUC_INST_ADDR_STATE_NA',true);cb(P+'dtlPrevEduc_ctl00_cbxEDUC_INST_POSTAL_CD_NA',true);
        se(P+'dtlPrevEduc_ctl00_ddlSchoolCountry','DOMR');
        fi(P+'dtlPrevEduc_ctl00_tbxSchoolCourseOfStudy',g('q154_carrera')||'Business Administration');
      }
    }
    else if(page==='P12'){
      setProgress(20,'Info adicional...');
      cl(P+'rblCLAN_TRIBE_IND_1');
      fi(P+'dtlLANGUAGES_ctl00_tbxLANGUAGE_NAME',g('q160_idiomas','Spanish'));
      cl(P+'rblCOUNTRIES_VISITED_IND_1');cl(P+'rblORGANIZATION_IND_1');
      cl(P+'rblSPECIALIZED_SKILLS_IND_1');cl(P+'rblMILITARY_SERVICE_IND_1');cl(P+'rblINSURGENT_ORG_IND_1');
    }
    else if(page==='P13'){
      setProgress(50,'Salud — todo NO...');
      cl(P+'rblDisease_1');await delay(80);cl(P+'rblDisorder_1');await delay(80);cl(P+'rblDruguser_1');
    }
    else if(page==='P14'){
      setProgress(20,'Criminal — todo NO...');
      ['Arrested','ControlledSubstances','Prostitution','MoneyLaundering','HumanTrafficking','AssistedSevereTrafficking','HumanTraffickingRelated'].forEach(async n=>{cl(P+'rbl'+n+'_1');await delay(60);});
    }
    else if(page==='P15'||page==='P16'){
      setProgress(20,'Seguridad — todo NO...');
      document.querySelectorAll('input[type="radio"][value="N"]').forEach(e=>{if(!e.checked)e.click();});
    }
    else if(page==='PFINAL'){
      setProgress(60,'Idiomas y preparador...');
      fi(P+'dtlLANGUAGES_ctl00_tbxLANGUAGE_NAME',g('q160_idiomas','Spanish'));
      document.querySelectorAll('input[type="radio"][value="N"]').forEach(e=>{if(e.id&&e.id.toLowerCase().includes('prepared')&&!e.checked)e.click();});
    }

    setProgress(100,'✅ Listo — presiona Next ›');
    document.getElementById('tvrd-btn').disabled=false;
    document.getElementById('tvrd-btn').textContent='▶ Rellenar de nuevo';
    document.getElementById('tvrd-btn').style.background='#16A34A';
    setStatus('✅ Página llenada — presiona Next ›','#EAF8EE','#15803d');
  }
})();
