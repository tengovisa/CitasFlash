# CitasFlash — Nexus Bot

## Arquitectura
- VPS: Contabo 147.93.185.71
- Panel: https://vps.citaflash.com/panel/
- API: FastAPI puerto 8000 (uvicorn)
- Bot: nexus.py (systemd service)
- BD: Supabase PostgreSQL
- Proxy: IPRoyal Residential geo.iproyal.com:12321

## Estructura
/bot/nexus.py          → Bot principal AIS
/api/api_control.py    → API REST 121 endpoints
/panel/index.html      → Panel web SPA
/config/.env.example   → Variables de entorno

## Servicios systemd
- nexus.service        → Bot agendador
- uvicorn (puerto 8000) → API
- nginx                → Proxy reverso HTTPS

## Flujo del bot
1. Login AIS con proxy residencial
2. Consulta fechas disponibles
3. Filtra por min_date/max_date del cliente
4. Reserva fecha disponible
5. Telegram + pausa cuenta + stop

## Proxy
- Formato: user:pass@host:port
- IPRoyal residential: geo.iproyal.com:12321
- Sin proxy → AIS bloquea IP Contabo

## Miércoles ULTRA
- 7:50 - 9:30 → delay 1.0s fijo
- Resto del día → delay random 0.8-2.0s
